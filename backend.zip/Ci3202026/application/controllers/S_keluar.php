<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class S_keluar extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_keluar');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 's_keluar/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 's_keluar/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 's_keluar/index.html';
            $config['first_url'] = base_url() . 's_keluar/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->M_keluar->total_rows($q);
        $s_keluar = $this->M_keluar->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            's_keluar_data' => $s_keluar,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
         $this->load->view('adminlte/header');
        $this->load->view('adminlte/navbar');
        $this->load->view('adminlte/sidebar');
        $this->load->view('s_keluar/tb_s_keluar_list', $data);
        $this->load->view('adminlte/footer');
    }

    public function read($id) 
    {
        $row = $this->M_keluar->get_by_id($id);
        if ($row) {
            $data = array(
		'id_suratk' => $row->id_suratk,
		'tgl_surat' => $row->tgl_surat,
		'indeks' => $row->indeks,
		'tujuan_surat' => $row->tujuan_surat,
		'bidang' => $row->bidang,
		'prihal' => $row->prihal,
	    );
            $this->load->view('adminlte/header');
        $this->load->view('adminlte/navbar');
        $this->load->view('adminlte/sidebar');
            $this->load->view('s_keluar/tb_s_keluar_read', $data);
            $this->load->view('adminlte/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('s_keluar'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('s_keluar/create_action'),
	    'id_suratk' => set_value('id_suratk'),
	    'tgl_surat' => set_value('tgl_surat'),
	    'indeks' => set_value('indeks'),
	    'tujuan_surat' => set_value('tujuan_surat'),
	    'bidang' => set_value('bidang'),
	    'prihal' => set_value('prihal'),
	);
        $this->load->view('adminlte/header');
        $this->load->view('adminlte/navbar');
        $this->load->view('adminlte/sidebar');
        $this->load->view('s_keluar/tb_s_keluar_form', $data);
        $this->load->view('adminlte/footer');
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'tgl_surat' => $this->input->post('tgl_surat',TRUE),
		'indeks' => $this->input->post('indeks',TRUE),
		'tujuan_surat' => $this->input->post('tujuan_surat',TRUE),
		'bidang' => $this->input->post('bidang',TRUE),
		'prihal' => $this->input->post('prihal',TRUE),
	    );

            $this->M_keluar->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('s_keluar'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->M_keluar->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('s_keluar/update_action'),
		'id_suratk' => set_value('id_suratk', $row->id_suratk),
		'tgl_surat' => set_value('tgl_surat', $row->tgl_surat),
		'indeks' => set_value('indeks', $row->indeks),
		'tujuan_surat' => set_value('tujuan_surat', $row->tujuan_surat),
		'bidang' => set_value('bidang', $row->bidang),
		'prihal' => set_value('prihal', $row->prihal),
	    );
             $this->load->view('adminlte/header');
        $this->load->view('adminlte/navbar');
        $this->load->view('adminlte/sidebar');
            $this->load->view('s_keluar/tb_s_keluar_form', $data);
             $this->load->view('adminlte/footer');
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('s_keluar'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_suratk', TRUE));
        } else {
            $data = array(
		'tgl_surat' => $this->input->post('tgl_surat',TRUE),
		'indeks' => $this->input->post('indeks',TRUE),
		'tujuan_surat' => $this->input->post('tujuan_surat',TRUE),
		'bidang' => $this->input->post('bidang',TRUE),
		'prihal' => $this->input->post('prihal',TRUE),
	    );

            $this->M_keluar->update($this->input->post('id_suratk', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('s_keluar'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->M_keluar->get_by_id($id);

        if ($row) {
            $this->M_keluar->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('s_keluar'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('s_keluar'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('tgl_surat', 'tgl surat', 'trim|required');
	$this->form_validation->set_rules('indeks', 'indeks', 'trim|required');
	$this->form_validation->set_rules('tujuan_surat', 'tujuan surat', 'trim|required');
	$this->form_validation->set_rules('bidang', 'bidang', 'trim|required');
	$this->form_validation->set_rules('prihal', 'prihal', 'trim|required');

	$this->form_validation->set_rules('id_suratk', 'id_suratk', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "tb_s_keluar.xls";
        $judul = "tb_s_keluar";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Surat");
	xlsWriteLabel($tablehead, $kolomhead++, "Indeks");
	xlsWriteLabel($tablehead, $kolomhead++, "Tujuan Surat");
	xlsWriteLabel($tablehead, $kolomhead++, "Bidang");
	xlsWriteLabel($tablehead, $kolomhead++, "Prihal");

	foreach ($this->M_keluar->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_surat);
	    xlsWriteNumber($tablebody, $kolombody++, $data->indeks);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tujuan_surat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->bidang);
	    xlsWriteLabel($tablebody, $kolombody++, $data->prihal);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=tb_s_keluar.doc");

        $data = array(
            'tb_s_keluar_data' => $this->M_keluar->get_all(),
            'start' => 0
        );
        
        $this->load->view('s_keluar/tb_s_keluar_doc',$data);
    }

}

/* End of file S_keluar.php */
/* Location: ./application/controllers/S_keluar.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-07-19 09:46:58 */
/* http://harviacode.com */