  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">HOME</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">

        <h2 style="margin-top:0px">masuk <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="date">Tgl Diterima <?php echo form_error('tgl_diterima') ?></label>
            <input type="text" class="form-control" name="tgl_diterima" id="tgl_diterima" placeholder="Tgl Diterima" value="<?php echo $tgl_diterima; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Asal Surat <?php echo form_error('asal_surat') ?></label>
            <input type="text" class="form-control" name="asal_surat" id="asal_surat" placeholder="Asal Surat" value="<?php echo $asal_surat; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Tgl Surat <?php echo form_error('tgl_surat') ?></label>
            <input type="text" class="form-control" name="tgl_surat" id="tgl_surat" placeholder="Tgl Surat" value="<?php echo $tgl_surat; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">No Surat <?php echo form_error('no_surat') ?></label>
            <input type="text" class="form-control" name="no_surat" id="no_surat" placeholder="No Surat" value="<?php echo $no_surat; ?>" />
        </div>
	    <div class="form-group">
            <label for="prihal">Prihal <?php echo form_error('prihal') ?></label>
            <textarea class="form-control" rows="3" name="prihal" id="prihal" placeholder="Prihal"><?php echo $prihal; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="varchar">Ket <?php echo form_error('ket') ?></label>
            <input type="text" class="form-control" name="ket" id="ket" placeholder="Ket" value="<?php echo $ket; ?>" />
        </div>
	    <input type="hidden" name="id_suratmsk" value="<?php echo $id_suratmsk; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('s_masuk') ?>" class="btn btn-default">Cancel</a>
	</form>
   </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->