  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">HOME</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <h2 style="margin-top:0px">keluar <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="date">Tgl Surat <?php echo form_error('tgl_surat') ?></label>
            <input type="text" class="form-control" name="tgl_surat" id="tgl_surat" placeholder="Tgl Surat" value="<?php echo $tgl_surat; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Indeks <?php echo form_error('indeks') ?></label>
            <input type="text" class="form-control" name="indeks" id="indeks" placeholder="Indeks" value="<?php echo $indeks; ?>" />
        </div>
	    <div class="form-group">
            <label for="tujuan_surat">Tujuan Surat <?php echo form_error('tujuan_surat') ?></label>
            <textarea class="form-control" rows="3" name="tujuan_surat" id="tujuan_surat" placeholder="Tujuan Surat"><?php echo $tujuan_surat; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="varchar">Bidang <?php echo form_error('bidang') ?></label>
            <input type="text" class="form-control" name="bidang" id="bidang" placeholder="Bidang" value="<?php echo $bidang; ?>" />
        </div>
	    <div class="form-group">
            <label for="prihal">Prihal <?php echo form_error('prihal') ?></label>
            <textarea class="form-control" rows="3" name="prihal" id="prihal" placeholder="Prihal"><?php echo $prihal; ?></textarea>
        </div>
	    <input type="hidden" name="id_suratk" value="<?php echo $id_suratk; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('s_keluar') ?>" class="btn btn-default">Cancel</a>
	</form>
 </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->